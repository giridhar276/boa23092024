
'''

tasks
-----
Write a program that removes all duplicate characters from a given string, preserving the order of first appearance.


Enter any string: programming
Output : progamin

Enter any string: aabbcc
Output : abc



'''



# Input from user
input_string = input("Enter any string: ")

#programming

result = ""

seen = set()

for char in input_string:
    if char not in seen:
        result += char
        seen.add(char)

# Print the result
print("Output:", result)
