


# traditional way
# regular way
fobj = open("customers1.txt","w")
fobj.write("oracle\n")
fobj.write("microsoft\n")
fobj.writelines(["google","salesforce"])
fobj.close()


# pythonic way
# context manager
# if any line starts using with keyword.. we call it context manager
# Advantage: file gets closed automatically
# other exmaples: network connections, db connections , excel files
with open("customers1.txt","w") as fobj:
    fobj.write("oracle\n")
    fobj.write("microsoft\n")
    fobj.writelines(["google","salesforce"])


