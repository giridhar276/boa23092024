## reading the file line by line - preferred
# fobj acts like cursor or pointer or reference
with open("customers.txt","r") as fobj:
    for line in fobj:
        print(line.strip())

# read the file using fobj.readlines()-----> list
with open("customers.txt","r") as fobj:
    print(fobj.readlines())

# using fobj.read() ----> string
# not suggested for larger files
# generally used for reading config of .env files
with open("customers.txt","r") as fobj:
    print(fobj.read())

print("******** csv ************")
# using csv library
import csv    #,on_bad_lines="skip"
with open("customers.txt","r") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    print(reader)
    for line in reader:
        #each line is automatically converted to list
        print(line)  


# using pandas
import pandas 
df = pandas.read_csv("customers.txt",on_bad_lines="skip")
print(df)


import json
with open("sales.json") as fobj:
    # converting file object to json object
    data = json.load(fobj)
    for key,value in data.items():
        print(key,value)


import openpyxl

