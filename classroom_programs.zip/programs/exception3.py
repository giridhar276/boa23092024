try:
    with open("customers1111.txt","r") as fobj:
            for line in fobj:
                print(line.strip())
except Exception as err:
     print(err)
output = "hello" + "hi"
print(output)