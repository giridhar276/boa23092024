
name = "python programming"
print(name)
print("I love",name)

# p   y   t   h   o   n     p   r   o    g  r    a    m   m   i    n  g
# 0   1   2   3 ..
#                                                        -4   -3  -2   -1
# string slicing
# string[start:stop:step]  # step is incremental index
print(name[0])
print(name[5])
print(name[0:6])
print(name[8:10])
print(name[0:18:1])
print(name[0:18:2])
print(name[::])  # python programming
print(name[:])   
print(name[-1])
print(name[-4:-1])
print(name[::-1])  # reverse the string

# string is immutable
name = "python programming"
print(name.upper())
print(name.upper())
print(name.lower())
print(name.encode("utf-16"))
print(name.center(30))
print(name.center(30,"*"))

print(name.count("p"))
print(name.count("P"))
print(name.count("P".lower()))
print(name.split(" "))  # output will be the list
print(name.startswith("p"))
print(name.startswith("q"))

print(name.find("gram")) # if existing it returns the starting index # if not existing .. it returns -1
print(name.isalnum())
alist = ["python","language"]
print(":".join(alist))   #python:language
aname = " python  "
print(len(aname))
print(len(aname.strip()))
print(len(aname.lstrip())) # remove the white spaces only at the left side
print(len(aname.rstrip()))

print(name.replace("python","java"))

name = name.replace("python","java")
print(name)



# ASCII :  0-255   ( uppercase,lowercase, number,special characters - english, latin)
# UTF-8 : 0-65535

# conditions
# simple if
if name.isupper():
    print("String is lower")
    print("inside if cond")
    print("still inside if cond")

# if-else
if name.startswith("p"):
    print("python programming")
else:
    print("some other langauge")

# if-elif-elif-else
if name.startswith("p"):
    print("python programming")
elif name.startswith("j"):
    print("java programing")
elif name.startswith("unix"):
    print("unix programming")
else:
    print("some other language")


name = "python"

for char in name:
    print(char)

for char in name[::-1]:
    print(char)

# numbers
for val in range(1,5):
    print(val)

alist = [10,20,30]
for val in alist:
    print(val)

for val in alist[::-1]:
    print(val)


name = "python programming"

if "gram" in name:
    print("substring exists")
else:
    print("substring doesnt exist")


alist = [10,20,30]
print(alist.append(40))
print(alist.reverse())
print(alist)


