
'''
write a program to reverse the words in the given sentence


Example:

Enter any sentence: Hello World
olleH dlroW

Enter any sentence: Python is fun
nohtyP si nuf

'''

#python programming
sentence = input("Enter any sentence :")  #python programming
rwords = list()
words = sentence.split(" ")               #["python","programming"]

for word in words:
    reversed_word = word[::-1]
    rwords.append(reversed_word)
print(rwords)  # ["nohtyp","gnimmargorp"]
finalsentence = " ".join(rwords)    #nohtyp gnimmargorp
print(finalsentence)