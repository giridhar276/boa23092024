# fixed arguments
def display(a,b):
    print(a,b)
# user defined funciton
display(10,20)


def display(a,b):
    c = a + b
    return c
# user defined funciton
total = display(10,20)
print(total)

# default argument
def display(a = 0,b = 0,c ="default"):
    print(a,b,c)
# user defined funciton
display()
display(10)
display(10,20)
display(10,20,30)

# keyword arguments
def display(b,a,c):
    print(a,b,c)
display(a= 10 , b=20 , c= 30)

# if any object begings with *  : it is tuple
# variable length arguments
def display(*args):
    print(type(args))
    for val in args:
        print(val)
    #print(sum(args))

display(10,20,30,40,50,60,70,80,90,100,"unix")

def display(**kwargs):
    print(kwargs)
    for key,value in kwargs.items():
        print(key,value)

display(a= 10 , b=20 , c= 30)



'''
# process the data from mysql database

def 1: connect to database
def 2: define query
def 3: execute query
def 4: process
def 5: display output
def 6: close connection
'''



def display(a,b):
    c = a + b
    return c
# user defined funciton
total = display(10,20)
print(total)



def display(bookinfo):
    for key,value in book.items():
        print(key,value)
book = {"chap1":10,"chap2":20}
display(book)



def display(chap1,chap2):
    print(chap1,chap2)
book = {"chap1":10,"chap2":20}
display(**book)








def display(a,b):
    c = a + b
    return c
# user defined funciton
total = display(10,20)
print(total)
