
'''

write a program to count the frequency of each item in the name.

Eg:

Enter any string : hello

Output:
{'h': 1, 'e': 1, 'l': 2, 'o': 1}


Enter any string : mississippi
{'m': 1, 'i': 4, 's': 4, 'p': 2}



'''


name = input("Enter any string :")
countdict = dict()
chars = list(name) # converting string to list
print(set(name))
for char in set(name):
    getcount = chars.count(char)
    countdict[char] = getcount
print(countdict)




