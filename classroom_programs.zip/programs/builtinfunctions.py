#capture input from keyword
name = input("Enter any name :")
print(name)

#range(start,stop,step)
print(list(range(1,10)))
print(list(range(1,10,2)))
print(list(range(2,10,2)))

alist = [10,20,30,40]
print(sum(alist))
print(max(alist))
print(min(alist))

# type() -display type of the object
print(type(alist))

# isinstance() = validating the type of object
print(isinstance(alist,list))

#  converting int to binary
print(bin(10))

# 97 is the ascii value of a
print(chr(97))

# display all builtin functions and exceptions
print(dir(__builtins__))

# zip() - combines two lists
names = ['Alice', 'Bob', 'Charlie']
ages = [25, 30, 35]
combined = zip(names, ages)
print(list(combined)) #[('Alice', 25), ('Bob', 30), ('Charlie', 35)]