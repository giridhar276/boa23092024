'''

Given a dictionary where keys are tuples representing a student's ID and name, and values are their respective scores in different subjects, group the data by subject and calculate the highest, lowest, and average scores for each subject.

student_scores = {
    ('S001', 'Alice'): {'Math': 85, 'Science': 90, 'English': 78},
    ('S002', 'Bob'): {'Math': 92, 'Science': 88, 'English': 80},
    ('S003', 'Charlie'): {'Math': 78, 'Science': 85, 'English': 85}
}


output:
{
    'Math': {'highest_score': 92, 'lowest_score': 78, 'average_score': 85},
    'Science': {'highest_score': 90, 'lowest_score': 85, 'average_score': 87.67},
    'English': {'highest_score': 85, 'lowest_score': 78, 'average_score': 81}
}

'''


student_scores = {
    ('S001', 'Alice'): {'Math': 85, 'Science': 90, 'English': 78},
    ('S002', 'Bob'): {'Math': 92, 'Science': 88, 'English': 80},
    ('S003', 'Charlie'): {'Math': 78, 'Science': 85, 'English': 85}
}

# Dictionary to hold the grouped data by subject
subject_scores = {}

# Iterate through each student's scores
for student, scores in student_scores.items():
    # Iterate through each subject and its score
    for subject, score in scores.items():
        # If the subject is not yet in the subject_scores, add it with an empty list
        if subject not in subject_scores:
            subject_scores[subject] = []
        # Append the score to the subject's list
        subject_scores[subject].append(score)

# Dictionary to hold the final results with highest, lowest, and average scores
result = {}

# Calculate the required values for each subject
for subject, scores in subject_scores.items():
    highest_score = max(scores)
    lowest_score = min(scores)
    average_score = round(sum(scores) / len(scores), 2)  # Rounded to 2 decimal places
    result[subject] = {
        'highest_score': highest_score,
        'lowest_score': lowest_score,
        'average_score': average_score
    }

# Print the result
print(result)
