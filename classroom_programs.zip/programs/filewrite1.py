



fobj = open("customers.txt","a")
fobj.write("oracle\n")
fobj.write("microsoft\n")
fobj.writelines(["google","salesforce"])
fobj.close()








#2
fnum = open("numbers.txt","w")
for val in range(1,10):
    fnum.write(str(val) + "\n")
fnum.close()





