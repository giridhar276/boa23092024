

atup = (10,20,30,40,50)


#org = 1000-->1200 -->1300

# list of lists
db = [["rita",20,"UK"],["ram",24,"UK"],["sinha",34,"UK"]]


# list of tuples
db = [("rita",20,"UK"),("ram",24,"UK"),("sinha",34,"UK"),(),()]

