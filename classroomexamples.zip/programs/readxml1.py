

import xml.etree.ElementTree as et


filename = "employees.xml"
tree = et.parse(filename)

root = tree.getroot()
print(root)

print("total no.of employees :",len(root.findall("employee")))
for employee in root.findall("employee"):
    id = employee.find("id").text
    name = employee.find("name").text
    department = employee.find("department").text
    print("Emp iD :",id)
    print("Name   :",name)
    print("Department :",department)
    print("--------------")





