

# read the file using fobj.readlines()-----> list
with open("customers.txt","r") as fobj:
    print(fobj.readlines()[0:3])
