aset = {10,10,20,20,20,30,30}
bset = {30,30,30,40,40,40,50}

# Error
#print(aset[0])   # indexing is applicable only for string, list tuple

# add new item to the set
aset.add(30)
print(aset)
print(bset)
# add new item to the set
aset.add(300)

print(aset)
print(bset)
print(aset.union(bset))
print(aset.intersection(bset))
print(aset.difference(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))

alist = [10,20,10,10,20,30]
print(set(alist))
name = "pppythonn"
print(set(name))


atup = (10,20,30,40)
alist  = list(atup)
alist.append(50)
atup = tuple(alist)
print(atup)

book = {"chap1":10,"chap2":20}
output = list(book.keys())
print(output)
