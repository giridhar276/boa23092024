
# framework we are importing Flask
from flask import Flask

app = Flask(__name__)


# A decorator is a python function that allows you to add new functionality to an existing object
#             witout modifying its structure


@app.route("/")   #decorator
def hello_world():  #  new functionality
    return "hello world"

@app.route("/customers")   #decorator
def displaycustomers():
    return "this is customers landing page"


@app.route("/projects")    # decorator
def displayprojects():
    return "this is projects landing page"



app.run(debug= True)




function1



newfunction  # new