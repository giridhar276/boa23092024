

class Employee():
    # constructor
    # constructor is invoked automatically when the object is created
    def __init__(self,name,age,city):
        self.name = name
        self.age = age
        self.city = city
    def displayEmployee(self):
        print(self.name)
        print(self.age)
        print(self.city)


#
emp1 = Employee()
emp1.displayEmployee()

emp2 = Employee('rena',23,'mumbai')
emp2.displayEmployee()