'''
write a program to display the below count:


Total male employees : xxxx
Total female employees : xxxx

'''
import os
import csv
import sys
try:
    malecount = 0
    femalecount =0
    filepath = "./files/employees.csv"
    if os.path.isfile(filepath) and os.path.getsize(filepath) > 0:
        with open(filepath,"r") as fobj:
            header = fobj.readline()
            reader = csv.reader(fobj)
            for line in reader:
                gender = line[9].strip()
                if gender == "Male":
                    malecount+=1
                elif gender == "Female":
                    femalecount+=1
    print("Total male employees :",malecount)
    print("Total female employees :",femalecount)

except Exception as err:
    print(err)


import pandas as pd
df = pd.read_csv("./files/employees.csv")
print(df['gender'].value_counts())






filepath = "./files/employees.csv"
with open(filepath,"r") as fobj:
    with open("output.csv","w") as fw:
        data = fobj.read()  # will return string
        data = data.replace(" Bachelors","Youngsters")
        print(data)
        fw.write(data)