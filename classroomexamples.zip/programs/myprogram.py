

import oopdemo


myobj = oopdemo.Employee()      
myobj.getEmployee('ram',12,'hyd')
myobj.displayEmployee()