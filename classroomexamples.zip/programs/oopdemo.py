

class Employee():
    def getEmployee(self,name,age,city):
        self.name = name
        self.age = age
        self.city = city
    def displayEmployee(self):
        print(self.name)
        print(self.age)
        print(self.city)

# if this program gets executed directly only below condition becomes true
# if this program is imported to other program the below condition becomes
if __name__ == "__main__":
    emp1 = Employee()
    emp1.getEmployee('Syam',32,'Hyd')
    emp1.displayEmployee()

    emp2 = Employee()
    emp2.getEmployee('rena',23,'mumbai')
    emp2.displayEmployee()