
'''

write a script to display the below information

1. CPU Usage
2. Memory info ( total memory, available, used)
3. process info
4. disk partitions
5. network statistics

'''