

import xml.etree.ElementTree as et


filename = "employees.xml"
tree = et.parse(filename)

root = tree.getroot()
print(root)

for employee in root.findall("employee"):
    if int(employee.find("id").text) == 101:
        name = employee.find('name').text
        print(name)

