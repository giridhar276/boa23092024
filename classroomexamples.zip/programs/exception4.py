

import sys
try:
    fobj =open("customers.txt","r")
except Exception as err:
    print("file not found")
    print(sys.exc_info())
else:
    try:
        for line in fobj:
            print(line)
    except TypeError as err:
        print(err)
finally:
    fobj.close()