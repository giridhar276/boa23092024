alist = [10,20,30,40,50,60,70,80]

#list slicing
print(alist[0:6:2])

# list methods
alist.append(90)
alist.append(100)
print('After appending :',alist)
# list.extend()
alist.extend([65,45,42,32])
print("After extending :",alist)
#list.insert(index,value)
alist.insert(1,15)
print("After inserting :",alist)
#list.pop(index) - remove item with the help of index
alist.pop(1)  # 1 is the index
print(alist)
#alist.remove(value) - value will be removed directly
alist.remove(30)
print("After removing :",alist)

# throws error
#alist.remove(300)
#print("After removing :",alist)

if 300 in alist:
    alist.remove(300)
else:
    print("Value doesnt exist")

# default is ascending order
alist.sort()
print("After sorting :",alist)
alist.sort(reverse=True)
print("After sorting :",alist)

# reversing all the elments
alist.reverse()
print("After reversing :",alist)


