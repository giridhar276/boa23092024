
'''

write a program to display the sum of salaries in each department


data = {
    'HR': {
        'Alice': {'age': 30, 'salary': 50000, 'role': 'Manager', 'years_in_role': 6},
        'Bob': {'age': 25, 'salary': 40000, 'role': 'Recruiter', 'years_in_role': 3}
    },
    'IT': {
        'Charlie': {'age': 35, 'salary': 70000, 'role': 'Developer', 'years_in_role': 8},
        'David': {'age': 28, 'salary': 65000, 'role': 'Analyst', 'years_in_role': 2}
    }
}


HR 
----
total sum of salaries : 90000


IT
-----
total sum of salaries : 135000


'''

book = {"HR":10,"IT":20}

data = {
    'HR': {
        'Alice': {'age': 30, 'salary': 50000, 'role': 'Manager', 'years_in_role': 6},
        'Bob': {'age': 25, 'salary': 40000, 'role': 'Recruiter', 'years_in_role': 3}
    },
    'IT': {
        'Charlie': {'age': 35, 'salary': 70000, 'role': 'Developer', 'years_in_role': 8},
        'David': {'age': 28, 'salary': 65000, 'role': 'Analyst', 'years_in_role': 2}
    }
}

print(data.items())
print("-----")

for key,value in data.items():
    salary = 0
    for emp,details in value.items():
        #print(emp,details)
        salary = salary + details['salary']
    
    print(key)
    print("----")
    print("total sum of salaries :",salary)
