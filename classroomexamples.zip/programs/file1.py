
import os
import csv
import sys
workset = set()
try:
    #with open("C:\\Admin\\Desktop\\programs\\employees.csv","r") as fobj:
    #with open(r"C:\Admin\Desktop\programs\employees.csv","r") as fobj:   # raw string
    #with open("C:/Admin/Desktop/programs/employees.csv","r") as fobj:
    filepath = "./files/employees.csv"
    if os.path.isfile(filepath) and os.path.getsize(filepath) > 0:
        with open(filepath,"r") as fobj:
            header = fobj.readline()
            reader = csv.reader(fobj)
            for line in reader:
                workset.add(line[1])
            #display output
            for item in workset:
                print(item.strip())

    else:
        print("file is not found")
        sys.exit(0)
except Exception as err:
    print(err)


