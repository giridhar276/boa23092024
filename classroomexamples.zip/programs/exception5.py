

import sys
import logging

# Configure logging
logging.basicConfig(
    filename='error_log.log',  # Log file name
    level=logging.ERROR,       # Log level (ERROR captures all errors)
    format='%(asctime)s - %(levelname)s - %(message)s'  # Log format
)

try:
    with open("customers.txt", "r") as fobj:
        for line in fobj:
            print(line.strip())
    output = "hello" + 4      # This will raise a TypeError
    
except TypeError as err:

    logging.error("TypeError: {}".format(err))
    print("Invalid operation")  # Still print a user-friendly message if needed
except ValueError as err:
    logging.error("ValueError: {}".format(err))
    print("Invalid input")
except FileNotFoundError as err:
    logging.error("FileNotFoundError: {}".format(err))
    print("File not found.. please check")
except (IndexError, KeyError) as err:
    logging.error("IndexError or KeyError: {}".format(err))
    print("Invalid index or key provided")
except Exception as err:
    logging.error("Unknown exception found: %s", err)
    logging.error("Exception info: %s", sys.exc_info())
    print("An unknown error occurred")

# The error_log.log file will now contain all the logged errors



