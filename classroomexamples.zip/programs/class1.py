



class Employee():
    def displayEmployee(self,city,age):
        print("Empname :","rita")
        print("city :",city)
        print("Age :",age)
    def output(self):
        print(city,age)

# object creation
emp1 = Employee()    
emp1.displayEmployee('hyd',25)
emp1.output()

# object creation
emp2 = Employee()    
emp2.displayEmployee('bang',34)