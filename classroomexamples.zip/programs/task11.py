

'''
Write a script that lists all files and directories in the current working directory line by line.

'''

import os
for file in os.listdir():
    if os.path.isfile(file):
        print(file,"is a file")
    if os.path.isdir(file):
        print(file,"is a directory")


import glob
files = glob.glob("*.py")
for file in files:
    print(file)



