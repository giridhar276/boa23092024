

import xml.etree.ElementTree as et


filename = "employeesnew.xml"
tree = et.parse(filename)

root = tree.getroot()
print(root)

for employee in root.findall("employee"):
    empid = employee.get("id")
    department = employee.get("department")
    print("Emp iD :",empid)

    print("Department :",department)
    print("--------------")


import json

fobj = open("abc.json","r")
# converting json file to dictionary
data= json.load(fobj)
for key,value in data.items():
