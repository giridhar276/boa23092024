

import sys
try:
    with open("customers1111.txt","r") as fobj:
        for line in fobj:
            print(line.strip())
    output = "hello" + "hi"

except TypeError as err:
    print(err)
    print("invalid operation")
    print(sys.exc_info())
except ValueError as err:
    print("Invalid input")
    print(err)
except FileNotFoundError as err:
    print("system generated error :",err)
    print("File not found.. please check")
except (IndexError,KeyError) as err:
    print("Invalid index or keyerror provided")
except Exception as err:
    print("Unknown exception found",err)
    print(sys.exc_info())