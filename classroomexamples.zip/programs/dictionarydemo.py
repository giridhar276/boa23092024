

book = {"chap1":10,"chap2":20,"chap3":30}
# adding new key-value to dictionary
book["chap4"] = 40
book["chap5"] = 50
print(book)

book["chap1"] = 100
print(book)
########################
# methods
########################
# display keys
print(book.keys())

for key in book.keys():
    print(key)

for key in book:   # reading keys
    print(key)

# display values
print(book.values())

for value in book.values():
    print(value)

# dislay items
print(book.items())

for key,value in book.items():
    print("key :", key)
    print("value:",value)
    print("-------------")


###
book.pop("chap1")  # key-value will be removed
print("After pop :",book)

book.popitem()   # last key-value will be removed
print("after popitem :",book)
book.popitem()   # last key-value will be removed
print("after popitem :",book)

# if key is not existing 
#print(book["chap9"])

print(book.get("chap9"))  #If key is not existing, returns None
print(book.get("chap3")) 

if "chap9" in book:
    print("key found")
else:
    print("key not found")


book = {"chap1":10,"chap2":20}
newbook= {"chap3":30,"chap4":40}



#method1
finalbook = {**book,**newbook}
print(finalbook)

#method2
book.update(newbook)
print("After updating :",book)


aname = "python"
bname = "programming"
finalname = aname + bname
print(finalname)





alist = [10,20,30]
blist = [40,50,60]
finalist = alist + blist
print(finalist)

atup = (40,45,50)
btup = (60,70,80)
finaltup = atup + btup
print(finaltup)



book1 = {"chap1":10}
book2 = {"chap1":100}

book1.update(book2)
print(book1)

