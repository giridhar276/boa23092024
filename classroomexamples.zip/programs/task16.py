


import filecmp
filecmp.
# File paths
file1 = 'file1.txt'
file2 = 'file2.txt'

# shallow=False : deep comparision , compare 2 files byte by byte
# even though the file size and modification timestamp are same.. it compare byte to byte

# shallow = True : if file size and modificatio time are same. it assumes fiels are identifical without checking the content


# Compare the files
are_identical = filecmp.cmp(file1, file2, shallow=False)

# Print the result
if are_identical:
    print("The files are identical.")
else:
    print("The files are not identical.")