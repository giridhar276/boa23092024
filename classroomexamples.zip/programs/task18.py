'''

write a program to read https://www.bankofamerica.com/  webpage and display all the URLs listed in the home page.

Output:
https://www.bankofamerica.com/#
https://www.bankofamerica.com/smallbusiness
https://www.ml.com/wealthmanagement.html
https://www.bankofamerica.com/credit-cards/
..
..
..


'''

# capture the html page   # import requests   or  # import urllib

# from the html page.. read all the urls  # import bs4  # extract content from html


import requests
from bs4 import BeautifulSoup

url = "https://www.bankofamerica.com/"
response = requests.get(url,verify=False)

if response.status_code == 200:
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    for link in soup.find_all('a'):
        url =link.get('href')
        print(url)

