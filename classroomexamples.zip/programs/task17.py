

import filecmp

# Directories to compare
dir1 = 'mydir1'
dir2 = 'mydir2'

# Compare the directories
comparison = filecmp.dircmp(dir1, dir2)

# Files only in mydir1
print("Files only in mydir1:")
for file in comparison.left_only:
    print(f"- {file}")

# Files only in mydir2
print("\nFiles only in mydir2:")
for file in comparison.right_only:
    print(f"- {file}")

# Files common to both directories
print("\nFiles common in both directories:")
for file in comparison.common_files:
    print(f"- {file}")
