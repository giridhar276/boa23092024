import sys
try:
    with open("customersfffdfd.txt","r") as fobj:
        for line in fobj:
            print(line.strip())
    a = "hello" + 4
except Exception as err:
    print("system generated error :",err)
    print(sys.exc_info())
print("regular code")