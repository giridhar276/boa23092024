


book = {"chap1":10 ,"chap2":20}

print(book.get("chap3"))