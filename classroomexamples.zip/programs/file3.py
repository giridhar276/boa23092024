


import fileinput
import os
filepath = "./files/employees.csv"
target = "Bachelors"
replacement = "Youngsters"


with fileinput.FileInput(filepath,inplace=True,backup=".csv") as file:
    for line in file:
        print(line.replace(target,replacement),end="")

newfile = filepath + ".bkp"  # employees.csv.bkp
os.rename(newfile,"abcd.csv.bkp")