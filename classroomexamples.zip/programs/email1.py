import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Define the SMTP server credentials
smtp_server = "smtp.gmail.com"
port = 587  # For TLS
sender_email = "your_email@gmail.com"
password = "your_password"  # Use App Password if 2FA is enabled

# Define the recipient and email content
recipient_email = "recipient@example.com"
subject = "Auto-generated Email"
body = """
Hello,

This is an auto-generated email sent using a Python script.

Best regards,
Your Python Script
"""

# Create a MIMEText message
message = MIMEMultipart()
message["From"] = sender_email
message["To"] = recipient_email
message["Subject"] = subject

# Attach the email body to the message
message.attach(MIMEText(body, "plain"))

# Securely connect to the SMTP server and send the email
try:
    # Create a secure SSL context
    context = ssl.create_default_context()

    # Connect to the SMTP server using the TLS port
    with smtplib.SMTP(smtp_server, port) as server:
        server.starttls(context=context)  # Secure the connection
        server.login(sender_email, password)  # Log in to the server
        server.sendmail(sender_email, recipient_email, message.as_string())  # Send the email
        print("Email sent successfully!")
except Exception as e:
    print(f"Error sending email: {e}")

