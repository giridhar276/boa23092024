def display(a,b):
    c = a + b
    return c
# user defined funciton
total = display(10,20)
print(total)

# 10 system calls - jumps

# if same block is called for 10 times  : 100 system calls



# lambda function : lambda is the replacement of single liner function only
# inline function in c++/java
# Advantage: function body will be replaced in the calling function
# syntax:
#functionname = lambda variables:expression

display = lambda x,y: x + y
# user defined funciton
total = display(10,20)
print(total)

converter = lambda x : int(x)
value = converter("1")
print(value)

square = lambda x : x ** 2
print(square(10))

checkeven = lambda x: x % 2 == 0
print(checkeven(10))

getsum = lambda *args : sum(args)
print(getsum(10,20,30,30,40,50,50,60,70))





alist = ["unix","python","c"]       
# [ 4, 6, 1]

# traditional way
getcount = []
for val in alist:
    getcount.append(len(val))
print(getcount)


# when len(input) = len(output)
#map()

#map(function,iterable)
alist = ["unix","python","c"]   
def getcount(x):
    return  len(x)
print(list(map(getcount,alist)))


# map with lambda
alist = ["unix","python","c"]   
getcount = lambda x: len(x)
print(list(map(getcount,alist)))


alist = ["unix","python","c"]   
print(list(map(lambda x: len(x),alist)))


numbers = [1, 2, 3, 4, 5]
squared_numbers = list(map(lambda x: x**2, numbers))
print(squared_numbers)  # Output: [1, 4, 9, 16, 25]


words = ['hello', 'world', 'python']
uppercase_words = list(map(lambda x: x.upper(), words))
print(uppercase_words)


list1 = [1, 2, 3]
list2 = [4, 5, 6]
sum_lists = list(map(lambda x, y: x + y, list1, list2))
print(sum_lists)  # Output: [5, 7, 9]


texts = ['  hello  ', ' world ', ' python ']
stripped_texts = list(map(lambda x: x.strip(), texts))
print(stripped_texts)  # Output: ['hello', 'world', 'python']


###############
## filter
###############
alist = ["unix","python","c","perl"]  
print(list(map(lambda x: len(x)==4, alist)))
print(list(filter(lambda x: len(x)==4, alist)))

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Filter even numbers
even_numbers = filter(lambda x: x % 2 == 0, numbers)
print(even_numbers)



## adding 10 to the positive numbers only
numbers = [-5, 3, -1, 7, -10, 2]
# Filter positive numbers
positive_numbers = filter(lambda x: x > 0, numbers)
# Map to add 10 to each positive number
increased_numbers = map(lambda x: x + 10, positive_numbers)

# Convert to list and print the result
result = list(increased_numbers)
print(result)  # Output: [13, 17, 12]




# processing customer reviews for analysis
'''
You have a list of customer reviews with their ratings, and you want to perform the following tasks:

Filter out only the reviews with a rating of 4 or higher (positive reviews).
Extract the length of each positive review.
Generate a summary by categorizing the reviews based on their length (short, medium, long).


'''


# List of customer reviews represented as (review_text, rating)
reviews = [
    ("Great product, highly recommend!", 5),
    ("Not what I expected, quality is poor.", 2),
    ("Decent quality for the price.", 4),
    ("Amazing! Exceeded my expectations.", 5),
    ("Just okay, nothing special.", 3),
    ("Would buy again, loved it!", 4),
    ("Terrible experience, will not buy again.", 1)
]

# Step 1: Filter out reviews with a rating of 4 or higher
positive_reviews = filter(lambda x: x[1] >= 4, reviews)
print("positive reviews:",list(positive_reviews))
# Step 2: Map to calculate the length of each positive review text
review_lengths = map(lambda x: (x[0], len(x[0])), positive_reviews)

# Step 3: Categorize each review as 'short', 'medium', or 'long' based on its length
def categorize_review(review):
    text, length = review
    if length < 30:
        category = 'short'
    elif 30 <= length < 50:
        category = 'medium'
    else:
        category = 'long'
    return (text, category)

categorized_reviews = map(categorize_review, review_lengths)

# Convert to a list to see the final result
result = list(categorized_reviews)

# Print the categorized reviews
print("Categorized positive reviews based on their length:")
for review, category in result:
    print(f"Review: \"{review}\", Category: {category}")

# Output:
# Categorized positive reviews based on their length:
# Review: "Great product, highly recommend!", Category: medium
# Review: "Decent quality for the price.", Category: short
# Review: "Amazing! Exceeded my expectations.", Category: medium
# Review: "Would buy again, loved it!", Category: short

